# Fit Explorer 0.1.3

Open FitExplorer.html in a modern browser. The synthetic RooFit example is
already loaded. Drop one compatible .root file anywhere on the page to open it.
Data guide includes copyable RooFit saving instructions. Everything runs locally.

This release fixes graphics resources retained when replacing a loaded fit.
Source code includes installation instructions, the Python saving helper,
MP4/GIF rendering, tests and full dependency license notices. Fit Explorer
is MIT licensed; bundled dependencies retain their own licenses.
